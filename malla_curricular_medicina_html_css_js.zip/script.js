
document.addEventListener("DOMContentLoaded", () => {
  const cursos = document.querySelectorAll(".curso");
  const progreso = document.getElementById("progreso");

  const guardados = JSON.parse(localStorage.getItem("aprobados")) || [];

  cursos.forEach(curso => {
    const id = curso.dataset.id;
    if (guardados.includes(id)) curso.classList.add("aprobado");

    curso.addEventListener("click", () => {
      if (!curso.classList.contains("desbloqueado")) return;
      curso.classList.toggle("aprobado");
      const nuevos = Array.from(document.querySelectorAll(".curso.aprobado"))
                          .map(c => c.dataset.id);
      localStorage.setItem("aprobados", JSON.stringify(nuevos));
      actualizarProgreso();
    });
  });

  function actualizarProgreso() {
    const total = cursos.length;
    const aprobados = document.querySelectorAll(".curso.aprobado").length;
    const porcentaje = Math.round((aprobados / total) * 100);
    progreso.textContent = `Progreso: ${porcentaje}%`;
  }

  actualizarProgreso();
});
